# Custom Model Training
Train a compact YOLO11s model on the unified dataset produced by the preparation step.
Use this CMD command to train:
    yolo detect train model="yolo11s.pt" data="combined/data.yaml" imgsz=640 epochs=10 batch=16 device=0 workers=8 cache=ram amp=True project="waste_sorting" name="marsycle"

## Why this matters
- Produces the **`best.pt`** you deploy in detection and dashboard.
- Lets you iterate quickly (small model, fast epochs) to reach demo-ready accuracy.

## Requirements
pip install ultralytics