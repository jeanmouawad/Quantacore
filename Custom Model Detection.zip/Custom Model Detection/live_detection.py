from ultralytics import YOLO
import cv2, torch, os, numpy as np
from torchvision import models, transforms
from PIL import Image
# -------------------- 1) Device --------------------
device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using device:", device)
# -------------------- 2) Load YOUR trained YOLO --------------------
# Adjust if your path differs:
YOLO_WEIGHTS = r"best.pt"
yolo_model = YOLO(YOLO_WEIGHTS)   # no need .to(); we pass device in predict()
class_names = yolo_model.names    # {0:'aluminum_can', 1:'plastic_bottle', 2:'fabric'}
# -------------------- 3) (Optional) Load material classifier --------------------
# If you do NOT have this file, the script will still run (it just won't add material labels).
MATERIAL_WEIGHTS = "minc_material.pth"
material_model = None
material_labels = ["plastic", "metal", "glass", "fabric"]
if os.path.isfile(MATERIAL_WEIGHTS):
    material_model = models.resnet18(pretrained=False)
    material_model.fc = torch.nn.Linear(material_model.fc.in_features, 4)
    material_model.load_state_dict(torch.load(MATERIAL_WEIGHTS, map_location=device))
    material_model.to(device).eval()
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])
    print("Loaded material model:", MATERIAL_WEIGHTS)
else:
    print("Material model not found -> skipping material classification.")
# -------------------- 4) Open USB camera --------------------
# Try index 1 first (your original), fall back to 0 if needed.
cam_index_order = [1, 0, 2]
cap = None
for idx in cam_index_order:
    cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW)
    if cap.isOpened():
        print(f"Opened camera index {idx}")
        break
if cap is None or not cap.isOpened():
    print("Cannot open camera on indexes:", cam_index_order)
    raise SystemExit(1)
# Optional: set a sane resolution (comment out if your cam rejects it)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
# Warmup (helps on first CUDA call)
_ = yolo_model.predict(source=np.zeros((480,640,3), dtype=np.uint8), imgsz=640, device=0 if device=="cuda" else "cpu", verbose=False)
CONF_THRESH = 0.35
# -------------------- 5) Main loop --------------------
while True:
    ok, frame_bgr = cap.read()
    if not ok:
        break
    # For speed, keep ~640 tall edge; adjust if you want higher res
    frame_vis = cv2.resize(frame_bgr, (960, 540), interpolation=cv2.INTER_LINEAR)
    # YOLO inference (numpy BGR is fine)
    results = yolo_model.predict(
        source=frame_vis,
        imgsz=640,
        device=0 if device == "cuda" else "cpu",
        conf=CONF_THRESH,
        verbose=False
    )
    if not results:
        cv2.imshow("YOLO + Material Detection", frame_vis)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        continue
    r0 = results[0]
    if r0.boxes is not None and len(r0.boxes) > 0:
        boxes = r0.boxes.xyxy.int().cpu().numpy()       # (N,4)
        confs = r0.boxes.conf.cpu().numpy()             # (N,)
        clses = r0.boxes.cls.int().cpu().numpy()        # (N,)
        H, W = frame_vis.shape[:2]
        for (x1, y1, x2, y2), conf, cls_id in zip(boxes, confs, clses):
            # clip to image bounds
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(W - 1, x2), min(H - 1, y2)
            if x2 <= x1 or y2 <= y1:
                continue
            # Draw YOLO box + label
            yolo_label = class_names.get(int(cls_id), str(cls_id))
            label_text = f"{yolo_label} {conf:.2f}"
            # (Optional) Material classification per crop
            material_text = ""
            if material_model is not None:
                crop = frame_vis[y1:y2, x1:x2]
                if crop.size > 0:
                    pil_img = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
                    inp = transform(pil_img).unsqueeze(0).to(device)
                    with torch.no_grad():
                        logits = material_model(inp)
                        midx = int(logits.argmax(dim=1).item())
                        material_text = f" | {material_labels[midx]}"
            # Box + text
            cv2.rectangle(frame_vis, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(
                frame_vis,
                label_text + material_text,
                (x1, max(0, y1 - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0),
                2,
                cv2.LINE_AA
            )
    cv2.imshow("YOLO + Material Detection", frame_vis)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()