# Custom Model Detection
This folder runs real-time inference with your trained YOLO model on a USB camera.  
Script: `live_detection.py`  
Weights: `best.pt` (produced by training)  

## Why this matters
- **Instant feedback loop** while collecting field footage.
- **Model sanity check** (class names, confidence, false positives).
- **Prep for robot control**: provides stable bounding boxes your arm logic can consume.

## Requirements
python -V   # 3.9–3.11 recommended
pip install ultralytics torch torchvision opencv-python pillow