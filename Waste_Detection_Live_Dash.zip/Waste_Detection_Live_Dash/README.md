# Live Dashboard
Script: `run_live_dashboard.py`  
A lightweight Flask app that streams the camera with detections, tracks **session** and **total** counts, ingests CSVs, and lets you export totals.

## Why this matters
- **One page demo** for judges: live feed + metrics + CSV explorer.
- **Persists totals** in `counts_totals.json` across runs.
- **Bridges research ↔ operations**: quick audits, data drops, and evidence.

## Install & Run
pip install flask ultralytics torch torchvision opencv-python pillow
python run_live_dashboard.py
