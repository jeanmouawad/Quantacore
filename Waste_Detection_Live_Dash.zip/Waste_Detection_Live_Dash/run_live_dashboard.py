#!/usr/bin/env python3
# run_live_dashboard.py
# Launches a Flask dashboard that shows:
# - Live camera feed with YOLO boxes (MJPEG stream)
# - Live session counts + cumulative counts (persisted)
# - CSV upload + preview + quick aggregation
# - Export cumulative counts to CSV
#
# Uses your working detection code as-is, embedded in a background thread.

import os, io, json, time, threading, csv
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from flask import Flask, Response, request, jsonify, send_file, make_response
import cv2
import numpy as np
from PIL import Image

import torch
from ultralytics import YOLO

# ---------- (Optional) Material classifier -----------
from torchvision import models, transforms

# -------------------- 0) Config --------------------
YOLO_WEIGHTS = r"best.pt"               # your trained model
MATERIAL_WEIGHTS = "minc_material.pth"  # optional
CONF_THRESH = 0.35

# Camera fallback sequence (Windows users: keep CAP_DSHOW)
CAM_INDEXES = [1, 0, 2, 3]
FRAME_SIZE = (960, 540)  # display size for speed

# persistence
PERSIST_JSON = Path("counts_totals.json")
EXPORT_COUNTS_CSV = Path("export_counts.csv")

# HTML template served at "/"
# (You can edit this string; or drop a separate file and read it.)
DASHBOARD_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Recycling Vision Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root { --fg:#111; --muted:#666; --bg:#fff; --accent:#0a84ff; --border:#ddd; }
* { box-sizing:border-box; }
body { margin:0; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; color:var(--fg); background:var(--bg);}
.header { padding:14px 18px; border-bottom:1px solid var(--border); display:flex; gap:12px; align-items:center; }
.header h1 { margin:0; font-size:20px; }
.header .spacer { flex:1; }
.main { display:flex; gap:18px; padding:18px; }
.left { flex: 2 1 0; }
.right { flex: 1 1 0; min-width: 360px; }
.panel { border:1px solid var(--border); border-radius:12px; padding:12px; margin-bottom:18px; background:#fff; }
.panel h2 { margin:0 0 10px; font-size:16px; }
#video { width:100%; border-radius:10px; border:1px solid var(--border); background:#000; }
.kv { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px dashed #eee; }
.kv:last-child { border-bottom:0; }
.counts { max-height: 340px; overflow:auto; border:1px solid var(--border); border-radius:10px; padding:8px; }
.small { color:var(--muted); font-size:12px; }
.upload { display:flex; gap:8px; align-items:center; }
.btn { display:inline-block; padding:8px 12px; border:1px solid var(--border); border-radius:8px; text-decoration:none; color:var(--fg);}
.btn:hover { border-color:var(--accent); color: var(--accent); }
table { border-collapse: collapse; width:100%; }
th, td { border:1px solid var(--border); padding:6px 8px; font-size:14px; }
thead th { background:#f8f8f8; text-align:left; }
.num { text-align:right; white-space:nowrap; }
</style>
</head>
<body>
  <div class="header">
    <h1>Recycling Vision Dashboard</h1>
    <div class="spacer"></div>
    <a class="btn" href="/export_counts.csv">Export Total Counts (CSV)</a>
  </div>
  <div class="main">
    <div class="left">
      <img id="video" src="/video" alt="Live Feed">
      <div class="small" id="meta" style="margin-top:6px;">—</div>
    </div>
    <div class="right">
      <div class="panel">
        <h2>Session Counts</h2>
        <div id="sessionCounts" class="counts"></div>
      </div>
      <div class="panel">
        <h2>Total Counts (Persisted)</h2>
        <div id="totalCounts" class="counts"></div>
      </div>
      <div class="panel">
        <h2>Upload CSV & Preview</h2>
        <form id="csvForm" class="upload">
          <input type="file" id="csvFile" name="file" accept=".csv" required>
          <button class="btn" id="csvUploadBtn" type="submit">Upload</button>
        </form>
        <div class="small" style="margin-top:8px;">Expected columns are flexible. We’ll try to aggregate by a column named <b>Material</b>, <b>Class</b>, or <b>Waste Item</b> if present.</div>
        <div id="csvSummary" style="margin-top:10px;"></div>
        <div id="csvPreview" style="margin-top:10px;"></div>
      </div>
    </div>
  </div>

<script>
async function fetchCounts() {
  try {
    const r = await fetch('/counts');
    const data = await r.json();

    const renderKV = (obj) => {
      const entries = Object.entries(obj).sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0]));
      if (entries.length === 0) return '<div class="small">No detections yet.</div>';
      return entries.map(([k,v]) => `<div class="kv"><div>${k}</div><div class="num">${v}</div></div>`).join('');
    };

    document.getElementById('sessionCounts').innerHTML = renderKV(data.session || {});
    document.getElementById('totalCounts').innerHTML = renderKV(data.total || {});
    document.getElementById('meta').textContent = `FPS: ${data.fps?.toFixed?.(1) ?? '-'} · Updated: ${new Date(data.ts*1000).toLocaleTimeString()}`;
  } catch (e) {
    // ignore transient errors
  } finally {
    setTimeout(fetchCounts, 500);
  }
}
fetchCounts();

document.getElementById('csvForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = document.getElementById('csvFile').files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append('file', f);
  const r = await fetch('/upload_csv', { method:'POST', body: fd });
  const data = await r.json();

  // summary
  const sum = data.aggregated || {};
  const rows = Object.entries(sum).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<tr><td>${k}</td><td class="num">${v}</td></tr>`).join('');
  document.getElementById('csvSummary').innerHTML =
    `<h3>Aggregated Counts</h3>
     <table><thead><tr><th>Label</th><th>Count</th></tr></thead><tbody>${rows || '<tr><td colspan="2"><i>No aggregatable column detected.</i></td></tr>'}</tbody></table>`;

  // preview
  if (data.preview && data.preview.length) {
    const cols = Object.keys(data.preview[0]);
    const head = cols.map(c=>`<th>${c}</th>`).join('');
    const body = data.preview.map(row => `<tr>${cols.map(c=>`<td>${row[c] ?? ''}</td>`).join('')}</tr>`).join('');
    document.getElementById('csvPreview').innerHTML =
      `<h3>Preview (first ${data.preview.length} rows)</h3>
       <table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
  } else {
    document.getElementById('csvPreview').innerHTML = '';
  }
});
</script>
</body>
</html>
"""

# -------------------- Globals (shared state) --------------------
app = Flask(__name__)

# counts
session_counts = defaultdict(int)
total_counts = defaultdict(int)

# fps tracking
_last_time = time.time()
_frame_counter = 0
_fps = 0.0

# latest JPEG frame for MJPEG streaming
latest_jpeg = None
state_lock = threading.Lock()

# CSV preview cache (from last upload)
csv_preview_rows = []
csv_aggregated = {}

# -------------------- Persistence helpers --------------------
def load_totals():
    if PERSIST_JSON.exists():
        try:
            data = json.loads(PERSIST_JSON.read_text(encoding='utf-8'))
            total_counts.clear()
            for k, v in data.items():
                total_counts[k] = int(v)
        except Exception:
            pass

def save_totals():
    try:
        PERSIST_JSON.write_text(json.dumps(total_counts, indent=2), encoding='utf-8')
    except Exception:
        pass

load_totals()

# -------------------- Camera + Detection Thread --------------------
def open_camera():
    cap = None
    for idx in CAM_INDEXES:
        cap = cv2.VideoCapture(idx, cv2.CAP_DSHOW)  # CAP_DSHOW OK on linux too; harmless if ignored
        if cap.isOpened():
            print(f"[INFO] Opened camera index {idx}")
            break
    if cap is None or not cap.isOpened():
        raise SystemExit(f"[ERROR] Cannot open camera on indexes: {CAM_INDEXES}")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    return cap

def detection_loop():
    global latest_jpeg, _last_time, _frame_counter, _fps

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    yolo_model = YOLO(YOLO_WEIGHTS)
    class_names = yolo_model.names  # {0:'aluminum_can',1:'plastic_bottle',2:'fabric',...}

    # (Optional) material classifier
    material_model = None
    material_labels = ["plastic", "metal", "glass", "fabric"]
    tfm = None
    if os.path.isfile(MATERIAL_WEIGHTS):
        material_model = models.resnet18(pretrained=False)
        material_model.fc = torch.nn.Linear(material_model.fc.in_features, 4)
        material_model.load_state_dict(torch.load(MATERIAL_WEIGHTS, map_location=device))
        material_model.to(device).eval()
        tfm = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor()])
        print("Loaded material model:", MATERIAL_WEIGHTS)
    else:
        print("Material model not found -> skipping material classification.")

    # warmup
    _ = yolo_model.predict(source=np.zeros((480,640,3), dtype=np.uint8), imgsz=640,
                           device=0 if device=="cuda" else "cpu", verbose=False)

    cap = open_camera()

    while True:
        ok, frame_bgr = cap.read()
        if not ok:
            time.sleep(0.02)
            continue

        frame_vis = cv2.resize(frame_bgr, FRAME_SIZE, interpolation=cv2.INTER_LINEAR)

        results = yolo_model.predict(
            source=frame_vis,
            imgsz=640,
            device=0 if device == "cuda" else "cpu",
            conf=CONF_THRESH,
            verbose=False
        )

        if results:
            r0 = results[0]
            if r0.boxes is not None and len(r0.boxes) > 0:
                boxes = r0.boxes.xyxy.int().cpu().numpy()
                confs = r0.boxes.conf.cpu().numpy()
                clses = r0.boxes.cls.int().cpu().numpy()
                H, W = frame_vis.shape[:2]

                for (x1, y1, x2, y2), conf, cls_id in zip(boxes, confs, clses):
                    x1, y1 = max(0, x1), max(0, y1)
                    x2, y2 = min(W - 1, x2), min(H - 1, y2)
                    if x2 <= x1 or y2 <= y1:
                        continue

                    yolo_label = class_names.get(int(cls_id), str(cls_id))
                    label_text = f"{yolo_label} {conf:.2f}"

                    # Update counts
                    with state_lock:
                        session_counts[yolo_label] += 1
                        total_counts[yolo_label] += 1

                    # Optional material classification
                    material_text = ""
                    if material_model is not None:
                        crop = frame_vis[y1:y2, x1:x2]
                        if crop.size > 0:
                            pil_img = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
                            inp = tfm(pil_img).unsqueeze(0).to(device)
                            with torch.no_grad():
                                logits = material_model(inp)
                                midx = int(logits.argmax(dim=1).item())
                                material_text = f" | {material_labels[midx]}"

                    # draw
                    cv2.rectangle(frame_vis, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame_vis, label_text + material_text, (x1, max(0, y1 - 8)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)

        # encode to JPEG for MJPEG streaming
        ok, jpg = cv2.imencode(".jpg", frame_vis, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
        if ok:
            with state_lock:
                latest_jpeg = jpg.tobytes()

        # FPS
        _frame_counter += 1
        now = time.time()
        if now - _last_time >= 1.0:
            _fps = _frame_counter / (now - _last_time)
            _frame_counter = 0
            _last_time = now
            save_totals()  # persist once a second is fine

# -------------------- Flask endpoints --------------------
@app.route("/")
def index_page():
    return Response(DASHBOARD_HTML, mimetype="text/html")

@app.route("/video")
def video_feed():
    # MJPEG stream from latest_jpeg
    def gen():
        boundary = b"--frame"
        while True:
            with state_lock:
                frame = latest_jpeg
            if frame is None:
                time.sleep(0.03)
                continue
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
            time.sleep(0.03)
    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")

@app.route("/counts")
def counts_json():
    with state_lock:
        session = dict(session_counts)
        total = dict(total_counts)
        fps = _fps
    return jsonify({"session": session, "total": total, "fps": fps, "ts": time.time()})

@app.route("/export_counts.csv")
def export_counts():
    # build CSV from total_counts
    with state_lock:
        items = sorted(total_counts.items(), key=lambda kv: (-kv[1], kv[0]))
    sio = io.StringIO()
    w = csv.writer(sio)
    w.writerow(["Label", "Count"])
    for k, v in items:
        w.writerow([k, v])
    mem = io.BytesIO(sio.getvalue().encode("utf-8"))
    return send_file(mem, mimetype="text/csv", as_attachment=True, download_name=EXPORT_COUNTS_CSV.name)

@app.route("/upload_csv", methods=["POST"])
def upload_csv():
    """
    Accept CSV and:
    - Keep first up to 30 rows as preview (dicts)
    - Aggregate counts by a best-guess label column: 'Material', 'Class', or 'Waste Item'
    """
    global csv_preview_rows, csv_aggregated
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "error": "No file"}), 400

    text = f.read().decode("utf-8", errors="replace")
    rdr = csv.DictReader(io.StringIO(text))
    rows = []
    for i, row in enumerate(rdr):
        if i < 30:
            rows.append(row)
    csv_preview_rows = rows

    # choose a label column if present
    cols = set(rows[0].keys()) if rows else set()
    label_col = None
    for cand in ["Material", "Class", "Waste Item", "Waste Item ", "Label"]:
        if cand in cols:
            label_col = cand
            break

    agg = defaultdict(int)
    if label_col:
        for r in rows:
            lab = (r.get(label_col) or "").strip()
            if lab:
                agg[lab] += 1

    csv_aggregated = dict(agg)
    return jsonify({"ok": True, "preview": rows, "aggregated": csv_aggregated})

def main():
    # spin up detection thread
    t = threading.Thread(target=detection_loop, daemon=True)
    t.start()
    # run web server
    # Tip: for LAN access, set host="0.0.0.0"
    app.run(host="127.0.0.1", port=5000, threaded=True, debug=False)

if __name__ == "__main__":
    main()