# Dataset Preparation 
Script: `prepare_dataset.py`  
Goal: Merge multiple YOLO datasets into a **single clean dataset** with unified class IDs and fixed filename quirks.

## Why this matters
- **One source of truth** for training (`combined/data.yaml`).
- **Forces consistent labels** across heterogeneous sources.
- **Auto-fixes** common export issues (`.rf.*` suffixes, `_jpg_jpeg` stems, case/extension noise).

Accepted image extensions: `.jpg .jpeg .png .bmp .webp` (any case)

## Class mapping
  "aluminum_cans": 0,
  "plastic_bottles": 1,
  "fabric": 2
