from pathlib import Path
import shutil, re

ROOT = Path(r"C:\Users\pc\Desktop\NASA_Space_Apps\datasets")
RAW  = ROOT / "raw"
OUT  = ROOT / "combined"

FORCE_MAP = {
    "aluminum_cans": 0,
    "plastic_bottles": 1,
    "clothing": 2
}
TARGET_NAMES = ["aluminum_can","plastic_bottle","fabric"]
IMG_EXTS = {".jpg",".jpeg",".png",".bmp",".webp",".JPG",".JPEG",".PNG",".BMP",".WEBP"}

def reset_out():
    if OUT.exists():
        shutil.rmtree(OUT)
    for split in ["train","val","test"]:
        (OUT / "images" / split).mkdir(parents=True, exist_ok=True)
        (OUT / "labels" / split).mkdir(parents=True, exist_ok=True)

def norm_stem(s: str) -> str:
    """Make label/image stems comparable: drop rf hash and trailing _jpg/_png/_jpeg (repeated)."""
    s0 = s
    # drop .rf.<hash> or _rf.<hash> or -rf.<hash> at end
    s = re.sub(r'([._-])?rf\.[0-9a-fA-F]{6,}$', '', s)
    # repeatedly strip one trailing -/_(jpg|jpeg|png|bmp|webp)
    changed = True
    while changed:
        s2 = re.sub(r'[-_](?:jpg|jpeg|png|bmp|webp)$', '', s, flags=re.I)
        changed = (s2 != s)
        s = s2
    # some weird double tags like *_jpeg_jpg
    changed = True
    while changed:
        s2 = re.sub(r'(?:[-_](?:jpg|jpeg|png|bmp|webp))+$', '', s, flags=re.I)
        changed = (s2 != s)
        s = s2
    return s

def build_image_index(images_root: Path):
    """Return dict of {key_lower: Path}, keys include raw stem and normalized stem."""
    idx = {}
    for p in images_root.rglob("*"):
        if not p.is_file() or p.suffix not in IMG_EXTS:
            continue
        k1 = p.stem.lower()
        k2 = norm_stem(k1)
        # prefer not to overwrite an existing exact match
        if k1 not in idx:
            idx[k1] = p
        # store normalized key too
        if k2 not in idx:
            idx[k2] = p
    return idx

def convert(ds_name: str, prefix: str):
    ds_dir = RAW / ds_name
    kept = 0
    missing_img = 0
    empty_lbl = 0
    tgt = FORCE_MAP[ds_name]

    for split_dir in ("train","valid","val","test"):
        ldir = ds_dir / split_dir / "labels"
        idir = ds_dir / split_dir / "images"
        if not ldir.exists() or not idir.exists():
            continue
        split = "val" if split_dir.lower() in ("val","valid") else ("test" if split_dir.lower()=="test" else "train")

        img_index = build_image_index(idir)

        for lbl in ldir.rglob("*.txt"):
            raw_key = lbl.stem.lower()
            key = raw_key if raw_key in img_index else norm_stem(raw_key)
            img = img_index.get(key)
            if img is None:
                missing_img += 1
                # print(f"[MISS] {lbl}")  # uncomment if you want the full list
                continue

            lines_raw = lbl.read_text().splitlines()
            if not lines_raw:
                empty_lbl += 1
                continue

            # force-map all class ids in this label file
            lines = []
            for line in lines_raw:
                s = line.strip()
                if not s:
                    continue
                parts = s.split()
                parts[0] = str(tgt)
                lines.append(" ".join(parts))
            if not lines:
                empty_lbl += 1
                continue

            stem = f"{prefix}_{img.stem}"
            out_img = OUT / "images" / split / f"{stem}{img.suffix}"
            out_lbl = OUT / "labels" / split / f"{stem}.txt"
            out_img.parent.mkdir(parents=True, exist_ok=True)
            out_lbl.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(img, out_img)
            out_lbl.write_text("\n".join(lines))
            kept += 1

    print(f"[OK] {ds_name}: kept {kept} labeled images. missing_img={missing_img}, empty_lbl={empty_lbl}")

def write_yaml():
    (OUT / "data.yaml").write_text(
f"""# unified dataset (forced mapping)
path: {OUT.as_posix()}
train: images/train
val: images/val
test: images/test

names:
  0: {TARGET_NAMES[0]}
  1: {TARGET_NAMES[1]}
  2: {TARGET_NAMES[2]}
""")

def main():
    reset_out()
    convert("aluminum_cans", "alc")
    convert("plastic_bottles", "plb")
    convert("clothing", "fab")
    write_yaml()
    print("\n[DONE] Combined dataset at:", OUT)

if __name__ == "__main__":
    main()
